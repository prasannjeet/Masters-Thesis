# Degree-Project-Proposal
Master's thesis proposal for - Distributed Information Flow Control in Serverless Computing

![Cover Page](https://raw.githubusercontent.com/prasannjeet/Degree-Project-Proposal/master/images/Degree%20Project%20Proposal-01.jpg)
![Index](https://raw.githubusercontent.com/prasannjeet/Degree-Project-Proposal/master/images/Degree%20Project%20Proposal-02.jpg)
